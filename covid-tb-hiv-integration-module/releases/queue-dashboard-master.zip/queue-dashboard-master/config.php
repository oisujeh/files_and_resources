<?php
@session_start();
error_reporting(0);
$con = mysqli_connect('127.0.0.1','db_user','db_user_pass','app_db','6033');
mysqli_set_charset('utf8',$con);
mysqli_query($con,"SET character_set_results = 'utf8', character_set_client = 'utf8', character_set_connection = 'utf8', character_set_database = 'utf8', character_set_server = 'utf8'");
//mysqli_query($con,"CREATE OR REPLACE VIEW queue_dashboard AS SELECT patient_queue.patient_queue_id, patient_queue.patient_id, patient_queue.location_to, patient_queue.status, patient_queue.date_created, patient_identifier.identifier, patient_identifier.patient_identifier_id, location.location_id, location.name FROM patient_queue INNER JOIN patient_identifier ON patient_queue.patient_id = patient_identifier.patient_id AND patient_identifier.identifier_type = 5 INNER JOIN location ON patient_queue.location_to = location.location_id WHERE patient_queue.status = 'PENDING' ORDER BY patient_queue.date_created ASC");


	if(!$con){
		echo "not connected";
		}
		else "connected";	

?>
