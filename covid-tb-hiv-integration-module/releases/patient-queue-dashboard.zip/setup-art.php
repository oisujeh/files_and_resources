<?php 
									include "config.php";



if($_POST['data_type']=='records'){
					mysqli_query($con,"CREATE OR REPLACE VIEW queue_dashboard3 AS SELECT patient_queue.patient_queue_id, patient_queue.patient_id, patient_queue.location_to, patient_queue.status, patient_queue.date_created, patient_queue.service_area_id, patient_identifier.identifier, patient_identifier.patient_identifier_id, location.location_id, location.name FROM patient_queue INNER JOIN patient_identifier ON patient_queue.patient_id = patient_identifier.patient_id AND patient_queue.service_area_id = 3 AND (patient_identifier.identifier_type = 5 OR patient_identifier.identifier_type = 3) INNER JOIN location ON patient_queue.location_to = location.location_id WHERE (location.location_id = 20 OR location.location_id = 21 OR location.location_id = 22) AND patient_queue.status = 'PENDING' ORDER BY patient_queue.date_created ASC");
					$table1_identifier = array();
					$table1_ids = array();
					$getrecord1 = mysqli_query($con,'(SELECT * FROM `queue_dashboard3` WHERE name = "Booth-1" order by `date_created` limit 1)');
					$gr1 = mysqli_fetch_array($getrecord1);
					$table1_identifier[0] = $gr1['identifier'];
					$table1_ids[0] = $gr1['patient_queue_id'];
					$getrecord2 = mysqli_query($con,'(SELECT * FROM `queue_dashboard3` WHERE name = "Booth-2" order by `date_created` limit 1)');
					$gr2 = mysqli_fetch_array($getrecord2);
					$table1_identifier[1] = $gr2['identifier'];
					$table1_ids[1] = $gr2['patient_queue_id'];
					$getrecord3 = mysqli_query($con,'(SELECT * FROM `queue_dashboard3` WHERE name = "Booth-3" order by `date_created` limit 1)');
					$gr3 = mysqli_fetch_array($getrecord3);
					$table1_identifier[2] = $gr3['identifier'];
					$table1_ids[2] = $gr3['patient_queue_id'];
					
					if($table1_identifier[1] == $table1_identifier[0]){
						
						$getrecord2 = mysqli_query($con,'(SELECT * FROM `queue_dashboard3` WHERE name = "Booth-2" && identifier != "'.$table1_identifier[0].'" order by `date_created` limit 1)');
						$gr2 = mysqli_fetch_array($getrecord2);
						$table1_identifier[1] = $gr2['identifier'];
						$table1_ids[1] = $gr2['patient_queue_id'];
						
					}
					
					if($table1_identifier[2] == $table1_identifier[0]){
						
						$getrecord3 = mysqli_query($con,'(SELECT * FROM `queue_dashboard3` WHERE name = "Booth-3" && (identifier != "'.$table1_identifier[0].'" && identifier != "'.$table1_identifier[1].'") order by `date_created` limit 1)');
						$gr3 = mysqli_fetch_array($getrecord3);
						$table1_identifier[2] = $gr3['identifier'];
						$table1_ids[2] = $gr3['patient_queue_id'];
						
					}
					else if($table1_identifier[2] == $table1_identifier[1]){
						
						$getrecord3 = mysqli_query($con,'(SELECT * FROM `queue_dashboard3` WHERE name = "Booth-3" && (identifier != "'.$table1_identifier[1].'" && identifier != "'.$table1_identifier[0].'") order by `date_created` limit 1)');
						$gr3 = mysqli_fetch_array($getrecord3);
						$table1_identifier[2] = $gr3['identifier'];
						$table1_ids[2] = $gr3['patient_queue_id'];
						
					}
					

?>

                        <div class="panel-list fulltable">
						<div class="row row-content">

                                            <br>
                            <div class="table-responsive-lg col-6" id="table-container">
<table class="table table-lg table-panel table-desktop">
                                    <thead align="center" style="background: rgba(12,185,126,1);color: white;">
                                        <tr class="clickable-row text-center">
                                            <th class="text-center" scope="col th-lg" style="font-size:4vh;font-weight:bold">Hospital Number</th>
                                            <th class="text-center" scope="col th-lg" style="font-size:4vh;font-weight:bold"">Booth</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                      
										
                                        <tr class="clickable-row text-center" >
                                        <td scope="col th-lg" style="font-size:4vh;font-weight:bold"><?php echo $table1_identifier[0] ?: '-' ?></td>
										<td scope="col th-lg" style="font-size:4vh;font-weight:bold">PLEASE GO TO Booth-1</td>
                                        </tr>
										
										<tr class="clickable-row text-center" >
                                        <td scope="col th-lg" style="font-size:4vh;font-weight:bold"><?php echo $table1_identifier[1] ?: '-' ?></td>
										<td scope="col th-lg" style="font-size:4vh;font-weight:bold">PLEASE GO TO Booth-2</td>
                                        </tr>
										
										<tr class="clickable-row text-center" >
                                        <td scope="col th-lg" style="font-size:4vh;font-weight:bold"><?php echo $table1_identifier[2] ?: '-' ?></td>
										<td scope="col th-lg" style="font-size:4vh;font-weight:bold">PLEASE GO TO Booth-3</td>
                                        </tr>
                                       
                                    </tbody>
                                </table> 
                                </div>
                        </div>
				</div>
                    
					
					
					
					<div class="panel-list fulltable" id="individual">
                                               
                                            <br>
                            <div class="table-responsive-lg col-12" id="table-container">
<table class="table table-lg table-panel table-desktop" id="dataTables-example-2">
                                    <thead align="center" style="background: rgba(52,54,68,1);color: white;">
                                        <tr>
											<th scope="col th-lg" style="font-size:4vh;font-weight:bold">#</th>
                                            <th scope="col th-lg" style="font-size:4vh;font-weight:bold">Hospital Number</th>
                                            <th scope="col th-lg" style="font-size:4vh;font-weight:bold">Booth</th>
											<th scope="col th-lg" style="font-size:4vh;font-weight:bold">Status</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                      <?php 
					
					$sno = 1;
					$getotherrecords = mysqli_query($con,'(SELECT * FROM `queue_dashboard3` WHERE (identifier != "'.$table1_identifier[0].'" || name != "Booth-1") && (identifier != "'.$table1_identifier[1].'" || name != "Booth-2") && (identifier != "'.$table1_identifier[2].'" || name != "Booth-3") order by `date_created`)');
					while($gor = mysqli_fetch_array($getotherrecords)){

					?>
                                        <tr class="clickable-row text-center" >
										<td scope="col th-lg" style="font-size:4vh;font-weight:bold"><?php echo $sno++; ?></td>
                                        <td scope="col th-lg" style="font-size:4vh;font-weight:bold"><?php echo $gor['identifier'] ?: '-' ?></td>
										<td scope="col th-lg" style="font-size:4vh;font-weight:bold"><?php echo $gor['name'] ?: '-' ?></td>
										<td scope="col th-lg" style="font-size:4vh;font-weight:bold"><?php echo 'QUEUED' ?></td>
                                        </tr>
										
					<?php } ?>					                                       
                                    </tbody>
                                </table> 
                                </div>
                        </div>
                            <?php } ?>
							
