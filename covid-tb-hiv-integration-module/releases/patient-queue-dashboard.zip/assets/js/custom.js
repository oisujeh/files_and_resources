$('#dataTables-example-2').dataTable( {
    "pagingType": "numbers"
} );