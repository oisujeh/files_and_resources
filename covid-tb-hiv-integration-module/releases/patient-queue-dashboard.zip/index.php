<?php 
@session_start();
include 'config.php';

?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Queue Dashboard</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
     <!-- MORRIS CHART STYLES-->
    <link href="assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
        <link href="assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
        <link href="assets/css/font-awesome.min.css" rel="stylesheet" />
<!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> --> 

     <!-- GOOGLE FONTS-->
<!--   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' /> -->
   <link href="assets/css/googlefont.css" rel="stylesheet" />
<!--      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> -->
      <script src="assets/js/ajax/jquery.min.js"></script>

  <script>
$(document).ready(function(e) {

loadrecords();

setInterval(function() {   //calls click event after a certain time
   loadrecords();
}, 30000);

function loadrecords(){		
 $.ajax({
        url: "getsetupsapi.php",
        dataType:"html",
        data: {
            data_type:'records',
		} ,
        type: "post",
		beforeSend: function()
		{
			$("#all_pages_table").html("<center><img src='assets/img/loader.gif' width='100' height='100'>Loading data please wait</td></center>");
		},
        success: function(res){
           $('#all_pages_table').html(res);
		   
		   var table = $('#dataTables-example-2').DataTable();
		   
	setInterval(function(){ 
       var info = table.page.info();
       var pageNum = (info.page < info.pages) ? info.page + 1 : 1;
       table.page(pageNum).draw(false);    
    }, 7000);

        }
    });
}	

});
</script>

<style>
.dataTables_length, #dataTables-example-2_filter{
	display:none;
}
</style>

</head>
<body>
    <div class="panel-list fulltable">

                     <script>
				function show()
    {
	$('.selectdata').css('display','block');
	$('#selecthead').css('display','block');

    };
    function hide()
    {
    	$('.selectdata').css('display','none');
    	$('#selecthead').css('display','none');
    };
				</script>  
                <style>
   .selectdata{
	   display:none;
	   }
   </style>        
					<div id="all_pages_table">
					</div>
                   
                                
                                
                            
                   
                    
                    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
     <!-- MORRIS CHART SCRIPTS -->
     <script src="assets/js/morris/raphael-2.1.0.min.js"></script>
    <script src="assets/js/morris/morris.js"></script>
      <!-- CUSTOM SCRIPTS -->
   
     <!-- DATA TABLE SCRIPTS -->
    <script src="assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
   
        
         <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
   
</body>
</html>
